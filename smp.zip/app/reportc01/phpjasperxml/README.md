PHPJasperXML
============

>>> Please not that our github repository is for new development that can be found in the Refractor branch. The master branch is the legecy code.



About PHPJasperXML
------------------
We initialize this project (Actually it is a class) because of we want to develop web report in php easily(The output of report is PDF because it platform indepent and printer friendly). This project allow php programmer design report with java iReport and run from PHP. This project is completely difference from php-java bridge, the code is run completely from PHP. A wrapper will convered report element from jrxml and pass to fpdf class.

This project still under Alpha stage, a lot of function is not ready. However, if you're expert in this project you'll found that it already can create a lot of reports.

Project Leader:
------------------
Ks Tan
Sim IT Sdn Bhd
kstan@simit.com.my

Core Programmer:
------------------
Ng Jey Ruey (Multimedia University Practical Student)
jeyrue@simit.com.my

License
------------------
I'll choose open source license for this project, however the type of license is not fix yet.


Installation
------------------
1. Download and extract this project into you website root directory (I assume /var/www)
2. Import sampledb.sql into mysql database, in this project we assume your username=root, password=mysql, database = phpjasperxml. If you use difference user/password/database, you shall change setting in sample1.php and sample2.php.
3. With your favorite web browser, browse into http://localhost/PHPJasperXML/index.php, test report you like.
4. Finish.


How to Use This Class
------------------
1. You can use iReport to edit the sample1.jrxml, sample2.jrxml and see the effect from web browser.
2. You can use any text editor to edit sample1.php and sample2.php, you will found that integrate the report into your project is like peanut.
3. Due to this project still at initial stage, to documentation is ready yet. However for those familiar with PHP and iReport should have no problem for using this class.

Join Development
------------------
1. Currently there is no any external programmer join into this project yet. If you feel interested into this project and willing to give your hand, simply create a topic in this forum: http://www.extraknowledge.org/forum/. Please take note this project use FPDF heavily.



Finally
------------------
This project is contribute by Sim IT Sdn Bhd, currently there is no commercial support yet. However for those company feel interest to establish long term relationship with SIm IT Sdn Bhd can visit our company website (Sim IT Sdn Bhd) and call our representative.
=======
PHPJasperXML ============ 
We initialize this project (Actually it is a
class) because of we want to develop web report in php easily (The
output of report is PDF/XLS because it platform indepent and printer
friendly). This project allow php programmer or report designer design
php web report easily. Even very junior PHP programmer able to design
the PDF/EXCEL report with iReport (java based WYSIWYG report designer),
but run natively in PHP. This project is completely difference from
php-java bridge, a wrapper class will convered report element from jrxml
and pass to tcpdf/PHPExcel class.


