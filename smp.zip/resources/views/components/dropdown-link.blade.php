<a {{ $attributes->merge(['class' => 'dropdown-item px-4']) }}>{{ $slot }}</a>
